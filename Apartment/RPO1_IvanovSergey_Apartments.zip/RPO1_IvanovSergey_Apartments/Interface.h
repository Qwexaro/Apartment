#pragma once

class CheckInfo { public: virtual void info() const = 0; };